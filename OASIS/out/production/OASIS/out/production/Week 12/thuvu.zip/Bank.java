import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.ArrayList;

public class Bank {
    private static final List<Customer> customerList = new ArrayList<>();

    Bank() {}

    public void readCustomerList(InputStream inputStream) {
        /*sử dụng câu lệnh try-with-resources để tự động đóng BufferedReaderkhi hoàn tất */
        /*InputStreamReaderđược sử dụng để giải mã các byte từ các InputStreamký tự thành các ký tự bằng bộ ký tự UTF-8. */
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
        
        StringBuilder file = new StringBuilder();
        int data = 0;
        
        while (data != -1) {
            try {
                data = bufferedReader.read();
            } catch (IOException e) {
                e.printStackTrace();
            }
            file.append((char) data);
        }

        file.deleteCharAt(file.length() - 1);

        String string = file.toString();
        String[] lines = string.split("\\r?\\n");

        Customer customer = null;

        for (String line : lines) {
            if (line.length() > 0) {
                if (Character.isAlphabetic(line.charAt(0))) {
                    customer = getCustomerFromFile(line);
                    customerList.add(customer);
                } else {
                    Account account = getAccountForCustomer(line);
                    assert customer != null;
                    customer.addAccount(account);
                }
            }
        }
    }

    public Account getAccountForCustomer(String line) {
        /*loại bỏ các khoảng trắng ở đầu và cuối dòng đầu vào. */
        line = line.trim();
        String[] words = line.split("\\s+");
        long accountNumber = Long.parseLong(words[0]);
        String accountType = words[1];
        double balance = Double.parseDouble(words[2]);
        return accountType.equals(Account.CHECKING) ? new CheckingAccount(accountNumber, balance) : new SavingsAccount(accountNumber, balance);
    }

    public Customer getCustomerFromFile(String line) {
        line = line.trim();
        String[] words = line.split("\\s+");
        String Id = words[words.length - 1];
        String name = line.replace(Id, "").trim();
        Id = Id.trim();
        long CMND = Long.parseLong(Id);
        return new Customer(CMND, name);
    }

    public String getCustomersInfoByNameOrder() {
        Collections.sort(customerList, Comparator.comparing(Customer::getFullName));
        return buildCustomerInfoString();
    }

    public String getCustomersInfoByIdOrder() {
        Collections.sort(customerList, Comparator.comparingLong(Customer::getIdNumber));
        return buildCustomerInfoString();
    }

    private String buildCustomerInfoString() {
        StringBuilder ans = new StringBuilder();
        for (int i = 0; i < customerList.size(); i++) {
            ans.append(customerList.get(i).getCustomerInfo());
            if (i != customerList.size() - 1) {
                ans.append("\n");
            }
        }
        return ans.toString();
    }

    public List<Customer> getCustomerList() {
        return customerList;
    }
}
