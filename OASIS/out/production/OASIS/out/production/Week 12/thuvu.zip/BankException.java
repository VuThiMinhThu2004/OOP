public class BankException extends java.lang.Exception {
    /**
     * Javadoc.
     * @param message.
     */
    public BankException(String message) {
        super(message);
    }
}
