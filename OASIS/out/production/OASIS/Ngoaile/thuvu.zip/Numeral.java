package Ngoaile;

public class Numeral extends Expression {
    private double value;

    public Numeral() {}
    /*
     * Javadoc.
     */
    public Numeral(double value) {
        this.value = value;
    }

    public String toString() {
        String s = Double.toString(value);
        if (s.length() >= 3 && s.charAt(s.length() - 2) == '.'
                && s.charAt(s.length() - 1) == '0') {
            s = s.substring(0, s.length() - 2);
        }
        return s;
    }

    public double evaluate() {
        return value;
    }

}
