package Ngoaile;

public class ExpressionTest {
    /**
     * Javadoc.
     */
    public static void main(String[] args) {
        Expression x = new Numeral(5);
        Expression y = new Numeral(2);
        Expression z = new Numeral(1);
        Expression t = new Numeral(3);


        // Calculate (5^2 - 2 + 1*3)^2
        Expression sq = new Square(a);
        Expression tmp = new Subtraction(sq, b);
        Expression mul = new Multiplication(c, d);
        Expression temp = new Addition(tmp, mul);
        Expression res = new Square(temp);

        System.out.println(res);


        //Test Exception
        Expression a = new Numeral(5);
        Expression b = new Numeral(0);
        Division ans = new Division(a, b);
        ans.evaluate();
    }
}
