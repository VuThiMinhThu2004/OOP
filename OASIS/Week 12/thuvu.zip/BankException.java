public class BankException extends java.lang.Exception {
    /**
     * Thu vu comment Javadoc.
     */
    public BankException(String message) {
        super(message);
    }
}
